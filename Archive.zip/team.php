<?php $page_title = 'Western Sydney Racing: Team'; include 'includes/header.php'; ?>
<?php $page_name = "team"; include 'includes/navbar.php'; ?>
  <div class="container">
    <div class="headings">
      <h3 class="page-headings">TEAM</h3>
    </div>
    <div class="sub-headings">
      <h4 class="sub-headings-text">Team Members (2017)</h4>
    </div>
    <div class="row">
      <div class="col-md-3 col-sm-4 col-xs-6 small-thumbnail" >
        <img class="small-img pull-left color-img" src="assets/images/team/team1.jpg" />
        <div class="team-caption-wrapper lead-caption-wrapper">
          <h4 class="lead-img-caption small-caption white-caption">John Doe</h4>
          <h5 class="lead-img-caption lead-designation small-designation white-caption">Team Lead</h5>
        </div>
      </div>
      <div class="col-md-3 col-sm-4 col-xs-6 small-thumbnail">
        <img class="small-img pull-left" src="assets/images/team/team1.jpg" />
        <div class="team-caption-wrapper">
          <h4 class="lead-img-caption small-caption">John Doe</h4>
          <h5 class="lead-img-caption lead-designation small-designation">Design Engineer</h5>
        </div>
      </div>
      <div class="col-md-3 col-sm-4 col-xs-6 small-thumbnail">
        <img class="small-img pull-left" src="assets/images/team/team1.jpg" />
        <div class="team-caption-wrapper">
          <h4 class="lead-img-caption small-caption">John Doe</h4>
          <h5 class="lead-img-caption lead-designation small-designation">Design Engineer</h5>
        </div>
      </div>
      <div class="col-md-3 col-sm-4 col-xs-6 small-thumbnail">
        <img class="small-img pull-left" src="assets/images/team/team1.jpg" />
        <div class="team-caption-wrapper">
          <h4 class="lead-img-caption small-caption">John Doe</h4>
          <h5 class="lead-img-caption lead-designation small-designation">Design Engineer</h5>
        </div>
      </div>
      <div class="col-md-3 col-sm-4 col-xs-6 small-thumbnail">
        <img class="small-img pull-left" src="assets/images/team/team2.jpg" />
        <div class="team-caption-wrapper">
          <h4 class="lead-img-caption small-caption">Jane Doe</h4>
          <h5 class="lead-img-caption lead-designation small-designation">Design Engineer</h5>
        </div>
      </div>
      <div class="col-md-3 col-sm-4 col-xs-6 small-thumbnail">
        <img class="small-img pull-left" src="assets/images/team/team2.jpg" />
        <div class="team-caption-wrapper">
          <h4 class="lead-img-caption small-caption">Jane Doe</h4>
          <h5 class="lead-img-caption lead-designation small-designation">Design Engineer</h5>
        </div>
      </div>
      <div class="col-md-3 col-sm-4 col-xs-6 small-thumbnail">
        <img class="small-img pull-left" src="assets/images/team/team2.jpg" />
        <div class="team-caption-wrapper">
          <h4 class="lead-img-caption small-caption">Jane Doe</h4>
          <h5 class="lead-img-caption lead-designation small-designation">Design Engineer</h5>
        </div>
      </div>
      <div class="col-md-3 col-sm-4 col-xs-6 small-thumbnail">
        <img class="small-img pull-left" src="assets/images/team/team2.jpg" />
        <div class="team-caption-wrapper">
          <h4 class="lead-img-caption small-caption">Jane Doe</h4>
          <h5 class="lead-img-caption lead-designation small-designation">Design Engineer</h5>
        </div>
      </div
      <div class="col-md-3 col-sm-4 col-xs-6 small-thumbnail">
        <img class="small-img pull-left" src="assets/images/team/team1.jpg" />
        <div class="team-caption-wrapper">
          <h4 class="lead-img-caption small-caption">John Doe</h4>
          <h5 class="lead-img-caption lead-designation small-designation">Design Engineer</h5>
        </div>
      </div>
      <div class="col-md-3 col-sm-4 col-xs-6 small-thumbnail">
        <img class="small-img pull-left" src="assets/images/team/team1.jpg" />
        <div class="team-caption-wrapper">
          <h4 class="lead-img-caption small-caption">John Doe</h4>
          <h5 class="lead-img-caption lead-designation small-designation">Design Engineer</h5>
        </div>
      </div>
      <div class="col-md-3 col-sm-4 col-xs-6 small-thumbnail">
        <img class="small-img pull-left" src="assets/images/team/team1.jpg" />
        <div class="team-caption-wrapper">
          <h4 class="lead-img-caption small-caption">John Doe</h4>
          <h5 class="lead-img-caption lead-designation small-designation">Design Engineer</h5>
        </div>
      </div>
      <div class="col-md-3 col-sm-4 col-xs-6 small-thumbnail">
        <img class="small-img pull-left" src="assets/images/team/team1.jpg" />
        <div class="team-caption-wrapper">
          <h4 class="lead-img-caption small-caption">John Doe</h4>
          <h5 class="lead-img-caption lead-designation small-designation">Design Engineer</h5>
        </div>
      </div>
      <div class="col-md-3 col-sm-4 col-xs-6 small-thumbnail">
        <img class="small-img pull-left" src="assets/images/team/team2.jpg" />
        <div class="team-caption-wrapper">
          <h4 class="lead-img-caption small-caption">Jane Doe</h4>
          <h5 class="lead-img-caption lead-designation small-designation">Design Engineer</h5>
        </div>
      </div>
      <div class="col-md-3 col-sm-4 col-xs-6 small-thumbnail">
        <img class="small-img pull-left" src="assets/images/team/team2.jpg" />
        <div class="team-caption-wrapper">
          <h4 class="lead-img-caption small-caption">Jane Doe</h4>
          <h5 class="lead-img-caption lead-designation small-designation">Design Engineer</h5>
        </div>
      </div>
      <div class="col-md-3 col-sm-4 col-xs-6 small-thumbnail">
        <img class="small-img pull-left" src="assets/images/team/team2.jpg" />
        <div class="team-caption-wrapper">
          <h4 class="lead-img-caption small-caption">Jane Doe</h4>
          <h5 class="lead-img-caption lead-designation small-designation">Design Engineer</h5>
        </div>
      </div>
      <div class="col-md-3 col-sm-4 col-xs-6 small-thumbnail">
        <img class="small-img pull-left" src="assets/images/team/team2.jpg" />
        <div class="team-caption-wrapper">
          <h4 class="lead-img-caption small-caption">Jane Doe</h4>
          <h5 class="lead-img-caption lead-designation small-designation">Design Engineer</h5>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include 'includes/footer.php' ?>
