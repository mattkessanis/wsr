<?php $page_title = 'Western Sydney Racing'; include 'includes/header.php'; ?>
<?php $page_name = "home"; include 'includes/navbar.php'; ?>
  <div class="hero-image"></div>
<?php include 'includes/footer.php' ?>
