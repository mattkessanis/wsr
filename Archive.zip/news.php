<?php $page_title = 'Western Sydney Racing: News'; include 'includes/header.php'; ?>
<?php $page_name = "news"; include 'includes/navbar.php'; ?>

  <div class="container">
    <div class="headings">
      <h3 class="page-headings">NEWS</h3>
    </div>
    <div class="row car-row">
    <div class="col-md-4 col-sm-6">
      <img class="car-img" src="assets/images/car/car1.jpg" />
      <h4 class="car-title">News Title Here</h4>
      <p class="car-description">News Decription Here.</p>
    </div>
    <div class="col-md-4 col-sm-6">
      <img class="car-img" src="assets/images/car/car2.jpg" />
      <h4 class="car-title">News Title Here</h4>
      <p class="car-description">News Decription Here.</p>
    </div>
    <div class="col-md-4 col-sm-6">
      <img class="car-img" src="assets/images/car/car1.jpg" />
      <h4 class="car-title">News Title Here</h4>
      <p class="car-description">News Decription Here.</p>
    </div>
    <div class="col-md-4 col-sm-6">
      <img class="car-img" src="assets/images/car/car1.jpg" />
      <h4 class="car-title">News Title Here</h4>
      <p class="car-description">News Decription Here.</p>
    </div>
    <div class="col-md-4 col-sm-6">
      <img class="car-img" src="assets/images/car/car2.jpg" />
      <h4 class="car-title">News Title Here</h4>
      <p class="car-description">News Decription Here.</p>
    </div>
    <div class="col-md-4 col-sm-6">
      <img class="car-img" src="assets/images/car/car1.jpg" />
      <h4 class="car-title">News Title Here</h4>
      <p class="car-description">News Decription Here.</p>
    </div>
  </div>
</div>

<?php include 'includes/footer.php' ?>
